This is the Mon09 6809 Monitor/Dissasembler/Debuger Desinged by David Dunfield
==============================================================================

This was coaxed to comple uder LWTOOLS by Johnny Quest as outlined here:

https://6809sbc.wordpress.com/

Addtional mods were made to enhance the monitor by JQ and myslelf a list
of the changes can be found in the .asm or in 'CHANGES'. While David dosen't
list a licence he did relase the code for 'any reasonable purpose'.

on his website:  https://dunfield.themindfactory.com
   "Daves Old Computers"

Addtional provisions provide that the above link and aknowlegement are provided

This particular version of the monitor supports 6309 'Trap' operations (which return to the monitor)

David's Documentation is included in the Docs and Schematics folder under the root.
